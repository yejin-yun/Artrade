package controller.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import model.Artwork;
import model.User;
import model.service.ExistingUserException;
import model.service.Manager;

public class RegisterArtworkController implements Controller {
    private static final Logger log = LoggerFactory.getLogger(RegisterUserController.class);

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {

		Artwork artwork = null;
		
		try {
            if(request.getMethod().equals("GET")){
                return "/artwork/registerForm.jsp";
            }

            //POST
            // 로그인 페이지의 자바스크립트로 빈창이 없는지 있는지 체크할 것. 
            artwork = new Artwork();
            artwork.setArtworkNo();
            artwork.setImage(request.getParameter("image")); 
            artwork.setWorkSize(request.getParameter("workSize"));
            artwork.setTitle(request.getParameter("title"));
            artwork.setArtist(request.getParameter("artist"));
            artwork.setKeyword(request.getParameter("keyword"));
            artwork.setDescription(request.getParameter("description"));
            artwork.setPrice(request.getParameter("price"));
            artwork.setLikeCnt(request.getParameter("likeCnt"));

            log.debug("Create Artwork : {}", user);

            Manager manager = Manager.getInstance();
            manager.create(artwork);
    
	        return "redirect:/user/registerArtwork";	// 성공 시 내가 올린 작품을 보는 페이지로 이동.
	        
		} catch (ExistingUserException e) {	// 예외 발생 시 회원가입 form으로 forwarding
            request.setAttribute("registerFailed", true);
			request.setAttribute("exception", e);
			request.setAttribute("user", user);
			return "/user/registerForm.jsp";
		}
    }
}
