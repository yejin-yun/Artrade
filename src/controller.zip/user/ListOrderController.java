package controller.user;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import controller.Controller;
import model.*;
import model.service.Manager;

public class ListOrderController implements Controller {
	// private static final int countPerPage = 100;	// �� ȭ�鿡 ����� ����� ��

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response)	throws Exception {
		// �α��� ���� Ȯ��
    	if (!UserSessionUtils.hasLogined(request.getSession())) {
            return "redirect:/user/login/form";		// login form ��û���� redirect
        }    
    	/*
    	String currentPageStr = request.getParameter("currentPage");	
		int currentPage = 1;
		if (currentPageStr != null && !currentPageStr.equals("")) {
			currentPage = Integer.parseInt(currentPageStr);
		}		
    	*/
        
        String deleteId = request.getParameter("userId");
        Manager manager = Manager.getInstance();	
    	User user = manager.findUser(deleteId);
        request.setAttribute("user", user);
        
		//UserManager manager = UserManager.getInstance(); //orderDao�� �̿���
        List<ArtworkOrder> artworkOrderList = manager.findArtworkOrderList(user.getUserNo());
        List<Onedayclass> applyOdcList = manager.findApplyOdcList(user.getUserNo());
        List<Exhibition> buyTicketExhList = manager.findBuyTicketExhList(user.getUserNo());

		// List<User> userList = manager.findUserList(currentPage, countPerPage);

		// userList ��ü�� ���� �α����� ����� ID�� request�� �����Ͽ� ����
        request.setAttribute("artworkOrderList", artworkOrderList);	
        request.setAttribute("applyOdcList", applyOdcList);
        request.setAttribute("buyTicketExhList", buyTicketExhList);			
		request.setAttribute("curUserId", 
				UserSessionUtils.getLoginUserId(request.getSession()));		

		// ����� ����Ʈ ȭ������ �̵�(forwarding)
		return "/user/orderList.jsp";        
    }
}
